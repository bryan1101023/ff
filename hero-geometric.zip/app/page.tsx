import HyreLanding from "@/components/hyre/landing-page"

export default function Home() {
  return <HyreLanding />
}

